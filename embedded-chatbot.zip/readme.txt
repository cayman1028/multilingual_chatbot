=== カスタムチャットボット ===
Contributors: 山崎　隆
Tags: chatbot, support, customer service, chat
Requires at least: 5.0
Tested up to: 6.2
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

企業サイト向けカスタマイズ可能なチャットボットを追加します。

== Description ==

このプラグインは、あなたのWordPressサイトにカスタマイズ可能なチャットボットを追加します。
訪問者はチャットボットを通じて、よくある質問への回答を得ることができます。

主な特徴:
* モダンでレスポンシブなデザイン
* カスタマイズ可能なQ&Aデータベース
* 自動応答機能
* モバイル対応

== Installation ==

1. プラグインのZIPファイルをアップロードするか、プラグインディレクトリにファイルを展開します。
2. WordPressの管理画面からプラグインを有効化します。
3. 「チャットボット」メニューから設定を行います。

== Frequently Asked Questions ==

= このチャットボットはどのように動作しますか？ =

このチャットボットは、事前に設定された質問と回答のデータベースを使用して、ユーザーの質問に自動的に回答します。


== Screenshots ==

1. チャットボットの外観
2. 管理画面の設定ページ

== Changelog ==

= 1.0.0 =
* 初回リリース
